const locations = {
  "AITR Main Campus":      { lat: 22.82143, lng: 75.94321, icon: "🏫", category:"admin" },
  "Computer Applications": { lat: 22.82278, lng: 75.94374, icon: "💻", category:"academic" },
  "MBA Block":             { lat: 22.82320, lng: 75.94405, icon: "🏢", category:"admin" },
  "Workshop":              { lat: 22.82215, lng: 75.94365, icon: "⚙️", category:"facility" },
  "Canteen":               { lat: 22.82245, lng: 75.94390, icon: "🍽️", category:"food" },
  "Block 3":               { lat: 22.82070, lng: 75.94285, icon: "🎓", category:"academic" },
  "Block 2":               { lat: 22.82055, lng: 75.94335, icon: "🏫", category:"academic" }
};

/*
  Public-map-grounded locations:
  - AITR main campus: 22.82143, 75.94321
  - Department of Computer Applications: 22.82278, 75.94374
  Public map data also lists MBA Block, Workshop, Canteen, Block 3 and Block 2
  near the campus. Their exact coordinates are not exposed in the source used here,
  so this prototype places them as approximate demo routing points.
*/
const edges = [
  ["AITR Main Campus", "Computer Applications", 160],
  ["AITR Main Campus", "Block 2", 120],
  ["AITR Main Campus", "Block 3", 150],
  ["Computer Applications", "MBA Block", 90],
  ["Computer Applications", "Workshop", 120],
  ["Computer Applications", "Canteen", 130],
  ["MBA Block", "Canteen", 100],
  ["Workshop", "Canteen", 90],
  ["Block 2", "Block 3", 70],
  ["Block 2", "Workshop", 180],
  ["Block 3", "Canteen", 220]
];

const startSelect = document.getElementById("start");
const destinationSelect = document.getElementById("destination");
const routeBtn = document.getElementById("routeBtn");
const accessible = document.getElementById("accessible");
const mapElement = document.getElementById("map");
const result = document.getElementById("result");
const resultEmpty = document.getElementById("resultEmpty");
const routeList = document.getElementById("routeList");
const distanceEl = document.getElementById("distance");
const timeEl = document.getElementById("time");
const toast = document.getElementById("toast");

const locationNames = Object.keys(locations);
let campusMap;
let mapMarkers = {};
let routeLine = null;

function populateSelects() {
  locationNames.forEach(name => {
    startSelect.add(new Option(name, name));
    destinationSelect.add(new Option(name, name));
  });
  startSelect.value = "AITR Main Campus";
  destinationSelect.value = "Computer Applications";
}

function initRealMap() {
  campusMap = L.map("map", {
    scrollWheelZoom: true
  }).setView([22.82143, 75.94321], 18);

  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 20,
    attribution: '&copy; OpenStreetMap contributors'
  }).addTo(campusMap);

  locationNames.forEach(name => {
    const p = locations[name];
    const marker = L.marker([p.lat, p.lng])
      .addTo(campusMap)
      .bindPopup(`<b>${p.icon} ${name}</b><br>CampusNav destination`);
    marker.on("click", () => {
      destinationSelect.value = name;
      calculateAndShow();
    });
    mapMarkers[name] = marker;
  });

  // Highlight the main campus location.
  L.circle([22.82143, 75.94321], {
    radius: 70,
    weight: 2,
    fillOpacity: 0.08
  }).addTo(campusMap);

  setTimeout(() => campusMap.invalidateSize(), 200);
}

function buildGraph() {
  const graph = {};
  locationNames.forEach(n => graph[n] = []);

  edges.forEach(([a, b, weight]) => {
    let adjusted = weight;
    if (accessible.checked && (a === "Block 3" || b === "Block 3")) adjusted += 500;
    if (avoidBusy.checked && (a === "Canteen" || b === "Canteen")) adjusted += 120;

    graph[a].push({ node: b, weight: adjusted });
    graph[b].push({ node: a, weight: adjusted });
  });

  return graph;
}

function dijkstra(start, target) {
  const graph = buildGraph();
  const distances = {};
  const previous = {};
  const unvisited = new Set(locationNames);

  locationNames.forEach(n => {
    distances[n] = Infinity;
    previous[n] = null;
  });
  distances[start] = 0;

  while (unvisited.size) {
    let current = null;
    let smallest = Infinity;

    for (const node of unvisited) {
      if (distances[node] < smallest) {
        smallest = distances[node];
        current = node;
      }
    }

    if (current === null) break;
    unvisited.delete(current);
    if (current === target) break;

    for (const edge of graph[current]) {
      if (!unvisited.has(edge.node)) continue;
      const alt = distances[current] + edge.weight;
      if (alt < distances[edge.node]) {
        distances[edge.node] = alt;
        previous[edge.node] = current;
      }
    }
  }

  if (distances[target] === Infinity) return null;

  const path = [];
  let current = target;
  while (current) {
    path.unshift(current);
    current = previous[current];
  }

  return { path, distance: Math.round(distances[target]) };
}

function drawRoute(path) {
  if (routeLine) {
    campusMap.removeLayer(routeLine);
    routeLine = null;
  }

  const latLngs = path.map(name => [locations[name].lat, locations[name].lng]);

  routeLine = L.polyline(latLngs, {
    weight: 7,
    opacity: 0.9
  }).addTo(campusMap);

  path.forEach((name, index) => {
    const marker = mapMarkers[name];
    if (marker) {
      marker.bindPopup(
        `<b>${index === 0 ? "START" : index === path.length - 1 ? "DESTINATION" : "ROUTE STOP"}</b><br>${locations[name].icon} ${name}`
      );
    }
  });

  campusMap.fitBounds(routeLine.getBounds(), { padding: [35, 35] });
}

function calculateAndShow() {
  const start = startSelect.value;
  const destination = destinationSelect.value;

  if (start === destination) {
    showToast("Start and destination are the same.");
    return;
  }

  const data = dijkstra(start, destination);
  if (!data) {
    showToast("No route found.");
    return;
  }

  drawRoute(data.path);
  distanceEl.textContent = `${data.distance} m`;
  timeEl.textContent = `${Math.max(1, Math.ceil(data.distance / 70))} min`;

  routeList.innerHTML = "";
  data.path.forEach((name, index) => {
    const li = document.createElement("li");
    li.textContent =
      name +
      (index === 0 ? " (Start)" : index === data.path.length - 1 ? " (Destination)" : "");
    routeList.appendChild(li);
  });

  resultEmpty.classList.add("hidden");
  result.classList.remove("hidden");
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 2600);
}

document.getElementById("swapBtn").addEventListener("click", () => {
  const temp = startSelect.value;
  startSelect.value = destinationSelect.value;
  destinationSelect.value = temp;
});

routeBtn.addEventListener("click", calculateAndShow);

document.getElementById("clearBtn").addEventListener("click", () => {
  if (routeLine) {
    campusMap.removeLayer(routeLine);
    routeLine = null;
  }
  result.classList.add("hidden");
  resultEmpty.classList.remove("hidden");
  campusMap.setView([22.82143, 75.94321], 18);
});

avoidBusy.addEventListener("change", () => {
  if (!result.classList.contains("hidden")) calculateAndShow();
});

accessible.addEventListener("change", () => {
  if (!result.classList.contains("hidden")) calculateAndShow();
});

document.querySelectorAll(".quick-card").forEach(button => {
  button.addEventListener("click", () => {
    const requested = button.dataset.dest;
    if (locationNames.includes(requested)) {
      destinationSelect.value = requested;
      calculateAndShow();
    } else {
      showToast("That location is not in the current public-map dataset.");
    }
    window.scrollTo({ top: 250, behavior: "smooth" });
  });
});

document.getElementById("emergencyBtn").addEventListener("click", () => {
  startSelect.value = "AITR Main Campus";
  destinationSelect.value = "Computer Applications";
  calculateAndShow();
  showToast("Emergency demo route started from the AITR main campus.");
});


const avoidBusy = document.getElementById("avoidBusy");
const showAll = document.getElementById("showAll");
const searchInput = document.getElementById("searchInput");
let activeCategory = "all";

function refreshLocationVisibility() {
  const query = searchInput.value.trim().toLowerCase();
  locationNames.forEach(name => {
    const p = locations[name];
    const matchesText = !query || name.toLowerCase().includes(query);
    const matchesCategory = activeCategory === "all" || p.category === activeCategory;
    const visible = matchesText && matchesCategory && showAll.checked;
    const marker = mapMarkers[name];
    if (marker) {
      if (visible) marker.addTo(campusMap);
      else campusMap.removeLayer(marker);
    }
  });
}

document.querySelectorAll(".category").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".category").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    activeCategory = btn.dataset.category;
    refreshLocationVisibility();
  });
});
searchInput.addEventListener("input", refreshLocationVisibility);
showAll.addEventListener("change", refreshLocationVisibility);

document.getElementById("themeBtn").addEventListener("click", () => {
  document.documentElement.classList.toggle("dark");
  document.getElementById("themeBtn").textContent = document.documentElement.classList.contains("dark") ? "☀️" : "🌙";
});

document.getElementById("nearbyBtn").addEventListener("click", () => {
  activeCategory = "all";
  searchInput.value = "";
  document.querySelectorAll(".category").forEach(b => b.classList.toggle("active", b.dataset.category === "all"));
  showAll.checked = true;
  refreshLocationVisibility();
  campusMap.setView([22.82143,75.94321],18);
  showToast("Showing campus locations around AITR.");
});

document.getElementById("resetBtn").addEventListener("click", () => {
  if (routeLine) { campusMap.removeLayer(routeLine); routeLine = null; }
  result.classList.add("hidden"); resultEmpty.classList.remove("hidden");
  campusMap.setView([22.82143,75.94321],18);
  showToast("Map reset to AITR campus overview.");
});

document.getElementById("infoBtn").addEventListener("click", () => {
  const panel=document.getElementById("infoPanel");
  panel.classList.toggle("hidden-panel");
  panel.scrollIntoView({behavior:"smooth",block:"center"});
});

document.getElementById("shareBtn").addEventListener("click", async () => {
  const start=startSelect.value, dest=destinationSelect.value;
  const text=`CampusNav AI route: ${start} → ${dest}`;
  try { await navigator.clipboard.writeText(text); showToast("Route details copied to clipboard."); }
  catch(e) { showToast(text); }
});

document.getElementById("closeModal").addEventListener("click",()=>document.getElementById("modal").classList.add("hidden-panel"));

populateSelects();
initRealMap();
setTimeout(refreshLocationVisibility, 500);
