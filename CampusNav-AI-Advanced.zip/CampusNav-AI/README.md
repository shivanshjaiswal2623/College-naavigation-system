# CampusNav AI — AITR Indore Edition

This hackathon prototype now uses a real OpenStreetMap basemap centered on **Acropolis Institute of Technology and Research (AITR), Manglaya Sadak, Indore**.

## Public-map data used
- AITR main campus: 22.82143, 75.94321
- Department of Computer Applications: 22.82278, 75.94374
- Public map data also identifies nearby Canteen, Block 3, Workshop, Block 2 and MBA Block.

## Important accuracy note
Only the two coordinates above were directly available from the public map sources used during development. The other campus destinations are placed as **approximate prototype routing points**, not claimed as surveyed coordinates.

For the final hackathon, the best upgrade is to replace those approximate points with coordinates collected on-site or from an official campus map.

## Run
1. Extract the ZIP.
2. Open the folder in VS Code.
3. Open `index.html`.
4. Make sure internet access is available because the live OpenStreetMap tiles and Leaflet library are loaded from the web.

## Technology
- HTML
- CSS
- JavaScript
- Leaflet
- OpenStreetMap
- Dijkstra shortest-path algorithm
